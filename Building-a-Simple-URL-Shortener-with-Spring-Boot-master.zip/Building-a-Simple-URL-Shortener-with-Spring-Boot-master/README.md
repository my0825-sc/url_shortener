# Building-a-Simple-URL-Shortener-with-Spring-Boot

YouTube link - https://youtu.be/xlFvb-3CbsE
